#include "life.h"
#include <pthread.h>
#include <semaphore.h>

void simulate_life_parallel1(int threads, LifeBoard *state, int steps) {
    // TODO
}